@echo off
chcp 65001 >nul
title Auto import timetable
cd /d "%~dp0"

rem ASCII-only on purpose: cmd.exe reads .bat with the OEM codepage and
rem garbles Chinese, which then breaks the following commands.

echo.
echo   ================================================
echo     Campus homepage - auto import timetable
echo   ================================================
echo.
echo   A browser window will open. Log in to jwxt.sztu.edu.cn there
echo   (captcha and SSO are handled by the browser; this tool never
echo   asks for or stores your password).
echo.
echo   Then open: left menu - training - my timetable - term timetable.
echo   The script grabs that table and sends it back to the website.
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo   [X] Node.js not found. Install the LTS build from https://nodejs.org/
  echo.
  pause
  exit /b 1
)

node "%~dp0tools\timetable-helper.mjs" %*
set CODE=%ERRORLEVEL%

echo.
echo   ------------------------------
if not "%CODE%"=="0" echo   Finished with exit code %CODE% - see messages above.
if "%CODE%"=="0" echo   Done. Click "Confirm import" in the page that just opened.
echo   ------------------------------
echo.
pause
